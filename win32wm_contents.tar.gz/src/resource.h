//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by properties.rc
//
#define IDD_PROPDIALOG                  101
#define IDD_PROPPAGE_SMALL              102
#define IDC_CHECK_DRAG                  1005
#define IDC_CHECK_VERTICAL              1008
#define IDC_CHECK_HORIZONTAL            1009
#define IDC_CHECK_RESIZE                1013
#define IDC_CHECK_RESIZE_RIGHT          1015
#define IDC_SNAP_EDIT                   1016
#define IDC_CHECK_SNAP                  1019
#define IDC_CHECK_MAXIMIZE              1020
#define IDC_CHECK_MINIMIZE              1022
#define IDC_CHECK_BACKGROUND            1023
#define IDC_CHECK_MDI                   1024
#define IDC_CHECK_VERTICAL_WIN          1025
#define IDC_CHECK_VERTICAL_CTRL         1026
#define IDC_CHECK_VERTICAL_ALT          1027
#define IDC_CHECK_VERTICAL_SHIFT        1028
#define IDC_EDIT_VERTICAL               1029
#define IDC_CHECK_HORIZONTAL_WIN        1030
#define IDC_CHECK_HORIZONTAL_CTRL       1031
#define IDC_CHECK_HORIZONTAL_ALT        1032
#define IDC_CHECK_HORIZONTAL_SHIFT      1033
#define IDC_EDIT_HORIZONTAL             1034
#define IDC_CHECK_MAXIMIZE_WIN          1035
#define IDC_CHECK_MAXIMIZE_CTRL         1036
#define IDC_CHECK_MAXIMIZE_ALT          1037
#define IDC_CHECK_MAXIMIZE_SHIFT        1038
#define IDC_EDIT_MAXIMIZE               1039
#define IDC_CHECK_MINIMIZE_WIN          1040
#define IDC_CHECK_MINIMIZE_CTRL         1041
#define IDC_CHECK_MINIMIZE_ALT          1042
#define IDC_CHECK_MINIMIZE_SHIFT        1043
#define IDC_EDIT_MINIMIZE               1044
#define IDC_CHECK_BACKGROUND_WIN        1045
#define IDC_CHECK_BACKGROUND_CTRL       1046
#define IDC_CHECK_BACKGROUND_ALT        1047
#define IDC_CHECK_BACKGROUND_SHIFT      1048
#define IDC_EDIT_BACKGROUND             1049
#define IDC_CHECK_ALT_BACKGROUND        1050

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1051
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
